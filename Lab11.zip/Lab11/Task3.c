#include<stdio.h>
main(){
    int i;
    float arr[20];
    printf("Enter elements:\n");
    for (i=0;i<20;i++){
    	scanf("%f", &arr[i]);
	}
	float *ptr;
	ptr = arr;
	float max = 0, smax=0;
	for(i=0;i<20;i++){
		if(*(ptr+i)>max){
			smax = max;
			max = *(ptr+i);
		}
	}
	printf("Second heighest in an array is: %.2f", smax);
}

