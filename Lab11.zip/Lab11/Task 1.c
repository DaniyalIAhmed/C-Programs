#include<stdio.h>
void swaped(int *, int *, int *);
main(){
    int a, b, c;
    printf("Enter one value:\n");
    scanf("%d", &a);
    printf("Enter second value:\n");
    scanf("%d", &b);
    printf("Enter third value:\n");
    scanf("%d", &c);
    printf("a: %d\nb: %d\nc: %d\n", a, b, c);
    swaped(&a,&b,&c);
    printf("a: %d\nb: %d\nc: %d\n", a, b, c);
}
void swaped(int *aptr, int *bptr, int *cptr){
	int temp;
	*aptr = *bptr;
	*cptr = *aptr;
    temp = *aptr;
    *bptr = temp;
}
