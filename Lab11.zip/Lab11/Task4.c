#include<stdio.h>
wordCount(char *p, int *size){
	int i, ctr = 0, wrd=0;
	for(i=0;*(p+i)!='\0';i++){
		if(*(p+i)==32)
		ctr++;
	}
	wrd = ctr+1;
	printf("Number of words in a sentence is: %d\n", wrd);
}

main(){
	int n =20;
	char arr[n];
    printf("Enter Text:\n");
    fflush(stdin);
    gets(arr);
    wordCount(arr, &n);
}

