#include<stdio.h>
#include<stdlib.h>
#include<string.h>
main(){
	char *p,fname[50],n;
	printf ("Enter number of characters in your name:\n");
	scanf ("%d" ,&n);
	p=(char*)malloc((n+2)*sizeof(char));
	printf ("Enter your full name:\n");
	fflush(stdin);
	gets(p);
	puts(p);	
}
