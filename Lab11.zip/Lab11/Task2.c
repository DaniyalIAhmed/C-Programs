#include<stdio.h>
main(){
	int n, i;
	printf("Enter number of elements in an array:\n");
	scanf("%d", &n);
    int arr[n];
    printf("Enter elements:\n");
    for (i=0;i<n;i++){
    	scanf("%d", &arr[i]);
	}
	int *ptr;
	ptr = arr;
	int sum = 0;
	for(i=0;i<n;i++)
	sum += *(ptr+i);
	printf("Sum of all elements in an array is: %d", sum);
}

