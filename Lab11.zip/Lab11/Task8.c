#include<stdio.h>
#include<stdlib.h>
#include<string.h>
main(){
	int i;
	char *p,fname[50],n,id[10],c[25];
	printf ("Enter number of characters in your name:\n");
	scanf ("%d" ,&n);
	p=(char*)malloc((n+2)*sizeof(char));
	printf ("Enter your name:\n");
	fflush(stdin);
	gets(p);
	strcpy(c,p);
//	puts(c);
	p=(char*)realloc(p,(9+n)*sizeof(char));
	for(i=0;i<9+n;i++)
	*(p+i)='/0';
	printf("Enter id:\n");
	gets(p);
	strcat(p,c);
	puts(p);	
}
