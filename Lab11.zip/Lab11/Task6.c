#include<stdio.h>
void scase(char *s){
	int i;
	for(i=0;*(s+i)!='\0';i++){
		if(*(s+0)>=97 && *(s+0)<=122){
			*(s+0)=*(s+0)-32;}
		if(*(s+i)=='.'){
			if(*(s+i+1)>=97 && *(s+i+1)<=122){
				i++;
				*(s+i)=*(s+i)-32;}}
		else if(*(s+i)>=65 && *(s+i)<=90){
			*(s+i)=*(s+i)+32;}}}
main(){
	int i;
	char *p, arr[50];
	printf ("Enter Text:\n");
	gets(arr);
	scase(arr);
	p=arr;
	for(i=0;*(p+i)!='\0';i++)
	printf ("%c",*(p+i));
}
