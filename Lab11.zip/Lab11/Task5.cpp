#include<stdio.h>
void descend(int *p, int size){
		int i,temp,j;
	for(i=1;i<size;i++){
		for(j=0;j<size-i;j++){
			if(*(p+j)<*(p+j+1)){
				temp=*(p+j);
				*(p+j)=*(p+j+1);
				*(p+j+1)=temp;
			}
		}
	}
	for(i=0;i<size;i++)
	printf ("%d ",*(p+i));
}
void ascend(int *p,int size){
	int i, j, temp;
	for(i=1;i<size;i++){
		for(j=0;j<size-i;j++){
			if(*(p+j)>*(p+j+1)){
				temp=*(p+j);
				*(p+j)=*(p+j+1);
				*(p+j+1)=temp;
			}
		}
	}
	for(i=0;i<size;i++)
	printf ("%d ",*(p+i));
}
main(){
	int i,size,*a,arr[100],choice;
	printf ("Enter array size=");
	scanf ("%d",&size);
	a=&arr[0];
	for(i=0;i<size;i++){
		printf ("Enter %d element=",i+1);
		scanf ("%d",a+i);
	}
	printf ("1_Ascending\n2_Decending\n");
	scanf ("%d",&choice);
	if(choice==1){
		ascend(&arr[0],size);
	}
	else if(choice==2){
		descend(&arr[0],size);
	}
	else
	printf("What are you doing?\n");	    
}
