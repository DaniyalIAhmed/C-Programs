#include<stdio.h>
main(){
    float n, s1=0, s2=0, s3=0, a, b, c;int i, j;
    FILE *fp;
    fp = fopen("budge.txt", "a");
/*  printf("Enter value:\n");
    for(i=0;i<10; i++){
    	for(j=0;j<3;j++){
    		scanf("%f", &n);
    		fprintf(fp, "%.2f\t", n);
		}
		fprintf(fp, "\n");
	}*/
	fclose(fp);
	fp = fopen("budge.txt", "r");
	for(i=0;i<10;i++){
	fscanf(fp, "%f\t%f\t%f\n", &a, &b, &c);
//	printf("%.2f, %.2f, %.2f\n", a, b,c);
    s1+=a;
    s2+=b;
    s3+=c;
}
    printf("Sum of column one: %.2f\nSum of column two: %.2f\nSum of column three: %.2f", s1, s2, s3);
}
