#include <stdio.h>
#include<stdlib.h>
int menu(void);
void input();
void printlist();
void deleterecord();
void updaterecord();

struct tools{
	int serial;
	char name[25];
	int quantity;
	float cost;
};

int main(){
      loop:
      int task=menu();
      
      switch (task){
      	    case 1:
      	  // 	 input();
      	   	 break;
      	   	
      	    case 2:
      	   	 printlist();
      	   	 break;
      	   	 
      	   	case 3:
      	   	  deleterecord();
      	   	  break;
      	   	
      	   	case 4:
      	   	  updaterecord();
      	   	  break;
      	   	  
      	   	case 5:
      	   	  exit(1);
      	   	  break;
	  }
	  char again;
	  printf("enter 'y' if you wish to perform another task: ");
	  scanf(" %c",&again);
	  if(again=='y')
	  goto loop;
}
int menu(void){
	int choice;
    printf("Select choice\n");
    printf("1.Input data.\n");
    printf("2.List tools.");
    printf("3.Delete record.\n");
    printf("4.Update record.\n");
    printf("5.Exit.\n");
    printf("Enter here: ");
    scanf("%d",&task);
    return choice;
}

void input(){
	FILE*ptr;
	ptr=fopen("hardware.txt","wb");
	      struct tools record;
	for(int i=1;i<=10;i++){
		printf("\n\nFor tool %d: ",i);
		printf("\n\tEnter record number: ");
		scanf("%d",&record.serial);;
		printf("\n\t\tEnter name: ");
		fflush(stdin);
		gets(record.name);
		printf("\n\t\tEnter quantity: ");
		scanf("%d",&record.quantity);
		printf("\n\t\tEnter cost: ");
		scanf("%f",&record.cost);
		fwrite(&record,sizeof(struct tools),1,ptr);
	}
	fclose(ptr);
}


void printlist(){
	FILE*ptr;
    ptr=fopen("hardware.txt","rb");
    struct tools record;
    while(fread(&record,sizeof(struct tools),1,ptr)!=NULL){
    	printf("\n\n\tRecord:%d\n\tName:%s\n\tQuantity:%2d\n\tCost:%.2f\n",record.serial,record.name,record.quantity,record.cost);
	}
	fclose(ptr);
}

void deleterecord(){
	struct tools record;
	FILE*ptr1;
	FILE*ptr2;
	ptr1=fopen("hardware.txt","rb");
	ptr2=fopen("hardware2.txt","wb");
	int serial;
	printf("Enter serial number of record to delete: ");
	scanf("%d",&serial);
	while(fread(&record,sizeof(struct tools),1,ptr1)!=NULL){
		if(record.serial!=serial){
			fwrite(&record,sizeof(struct tools),1,ptr2);
		}
	}
	fclose(ptr1);
	fclose(ptr2);
	remove("hardware.txt");
	rename("hardware2.txt","hardware.txt");
}

void updaterecord(){
	struct tools record;
	FILE*ptr1;
	FILE*ptr2;
	ptr1=fopen("hardware.txt","rb");
	ptr2=fopen("hardware2.txt","wb");
	int serial;
	printf("Enter serial number of record you wish to update : ");
	scanf("%d",&serial);
	while(fread(&record,sizeof(struct tools),1,ptr1)!=NULL){
		if(record.serial!=serial){
				printf("\n\t\tEnter new quantity: ");
		        scanf("%d",&record.quantity);
		        printf("\n\t\tEnter new cost: ");
		        scanf("%f",&record.cost);
			    fwrite(&record,sizeof(struct tools),1,ptr2);
		}
		else 	fwrite(&record,sizeof(struct tools),1,ptr2);
	}
	fclose(ptr1);
	fclose(ptr2);
	remove("hardware.txt");
	rename("hardware2.txt","hardware.txt");
}




