#include<stdio.h>
#include<string.h>
int main(){
	int n, i;FILE*fp;
	printf("Enter number of students: ");
	scanf("%d",&n);
	struct student{
   int rollNo;
   char name[20];
   char dep[10];
   int batch;
   char sec;
}s[n];
	
	fp=fopen("data.txt","wb");
	for(int i=0;i<n;i++){
		printf("\nEnter Roll Number: ");
		scanf("%d",&s[i].rollNo);
		printf("\nEnter Student Name: ");
		fflush(stdin);
		gets(s[i].name);
		printf("\nEnter Department Name: ");
		fflush(stdin);
		gets(s[i].dep);
		printf("\nEnter Batch Number: ");
		scanf("%d", &s[i].batch);
		printf("\nEnter Section: ");
		scanf(" %c",&s[i].sec);
		fwrite(&s[i],sizeof(struct student),1,fp);
	}
	fclose(fp);
	fp=fopen("data.txt","rb");
	int src;
	printf("Enter roll number: ");
	scanf("%d",&src);
	for(i=0;fread(&s[i],sizeof(struct student),1,fp)!=NULL;i++){
		if(s[i].rollNo==src){
			printf("\nRoll number:%d\n",s[i].rollNo);
			printf("Name: %s\n", s[i].name);
			printf("Department: %s\n", s[i].dep);
			printf("Batch: %s\n", s[i].batch);
			printf("Section: %c\n", s[i].sec);
			break;
		}
	}
	fclose(fp);
	
	printf("\nStudents of Batch 2022:\n");
	fp=fopen("data.txt","rb");
    i=0;
	for(i=0;fread(&s[i],sizeof(struct student),1,fp)!=NULL;i++){
		if(s[i].batch==2022){
			printf("\nRoll number:%d\n",s[i].rollNo);
			printf("Name: %s\n", s[i].name);
			printf("Department: %s\n", s[i].dep);
			printf("Batch: %d\n", s[i].batch);
			printf("Section: %c\n", s[i].sec);
		}
	}
	fclose(fp);
}
