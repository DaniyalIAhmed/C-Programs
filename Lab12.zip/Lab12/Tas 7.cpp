#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define max 200
main(){
	char o[max];
	char en[max];
	FILE *fp,*ptr;
	fp=fopen("origin.txt","r+");
	if(ptr1==NULL){
	printf("File not Exist!\n");
	exit(1);
	}
	ptr=fopen("encrypt.txt","a");
	while(!feof(ptr1))
	{
		int index=0;
		o[max]='\0';
		en[max]='\0';
		fgets(o,max,ptr1);
		o[max-1]='\0';
		for(int i=0;i<strlen(o);i++)
		{
		
			if(o[i]=='a'||o[i]=='e'||o[i]=='i'||o[i]=='o'||o[i]=='u'||o[i]=='A'||o[i]=='I'||o[i]=='O'||o[i]=='E'||o[i]=='U'){
				index+=4;
				if(i%2==0){
				strcat(en,"vow");
				continue;
				}
				else{
					strcat(en,"VOW");
				    continue;
				}
				
			}
			else if(o[i]=='s' && o[i+1]=='s' && o[i+2]=='s'){
				index+=7;
				strcat(en,"PF_Lab");
				continue;
			}
			else {
				en[index]=o[i];
			}
//			printf("%s\n",en);
		}
		for(int i=0;i<strlen(en);i++){
			if(en[i]=='-'||en[i]==32)
			continue;
			else if(en[i]=='x'||en[i]=='y'||en[i]=='z'){
				en[i]-=23;
	            continue;
			}
			else {
				en[i]+=3;
			}
		}
		fprintf(ptr2,"%s\n",en);
//		printf("%s",en);
	}
	fclose(ptr1);
	fclose(ptr2);
}
