#include<stdio.h>
main(){
    char sen[100];int i, j, ctr = 0;
    char ach = 'A', sch= 'a'; 
    FILE *fp;
    fp = fopen("a.txt", "r");
    fgets(sen, 100, fp);
    fclose(fp);
	puts(sen);
	for(i=0;i<26;i++){
		for(j=0;sen[j]!='\0';j++){
			if(sen[j]==ach||sen[j]==sch){
				ctr++;
			}
		}
		printf("%c occured %d times\n", ach, ctr);
		ach++;
		sch++;
		ctr=0;
	}
}

