#include<stdio.h>
main(){
    struct data{
    	char id[10];
    	char name[15];
    	char sex[10];
    	float q1, final, total;
    	float q2;
		float mid;   	
	} std;
	int i, j;
	FILE *fp;
	fp= fopen("data.bin", "wb");
	for(i=0;i<20;i++){
		fflush(stdin);
		printf("Enter Student %d id:\n", i+1);
		fflush(stdin);
		scanf("%s", std.id);
		fflush(stdin);
		printf("Enter name:\n");
		fflush(stdin);
		gets(std.name);
		fflush(stdin);
		printf("Enter sex:\n");
		fflush(stdin);
		gets(std.sex);
		printf("Enter quiz 1 marks:\n");
		fflush(stdin);
		scanf("%f", &std.q1);
		fflush(stdin);
		fflush(stdin);
		printf("Enter quiz 2 marks:\n");
		fflush(stdin);
		scanf("%f", &std.q2);
		fflush(stdin);
		printf("Enter mid marks:\n");
		fflush(stdin);
		scanf("%f", &std.mid);
		printf("Enter final marks:\n");
		fflush(stdin);
		scanf("%f", &std.final);
		std.total = std.q1+std.q2+std.mid+std.final;
		fwrite(&std,sizeof(struct data),1,fp);
	}
	fclose(fp);
	fp=fopen("data.bin","rb");
    while(fread(&std,sizeof(struct data),1,fp)!=NULL){
   	    if(std.total<50){
   		printf("Student id: %s\nStudent name : %s\nGender:%s\nQuiz 1: %.2f\nQuiz 2: %.2f\nMid term: %.2f\nFinals:%.2f\nTotal:%.2f\n ",std.id,std.name,std.sex,std.q1,std.q2,std.mid,std.final,std.total);
	    }
	    if(std.total<80){
   		printf("Student id: %s\nStudent name : %s\nGender:%s\nQuiz 1: %.2f\nQuiz 2: %.2f\nMid term: %.2f\nFinals:%.2f\nTotal:%.2f\n ",std.id,std.name,std.sex,std.q1,std.q2,std.mid,std.final,std.total);
	    }
   }
   fclose(fp);
}

