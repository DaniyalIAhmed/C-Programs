#include<stdio.h>
main(){
	FILE *fp;
    char a[100], b[100];
    printf("Enter any text:\n");
    gets(a);
    fp = fopen("a1.txt","w");
    fputs(a, fp);
    fclose(fp);
    printf("Enter another text:\n");
    gets(b);
    fp = fopen("b1.txt", "w");
    fputs(b, fp);
    fclose(fp);
    fp = fopen("a1.txt","r");
    fgets(a, 100,fp);
    fclose(fp);
    fp = fopen("b1.txt", "r");
    fgets(b, 100,fp);
    fclose(fp);
    fp = fopen("c1.txt", "w");
    fputs(a, fp);
    fputs(" ", fp);
    fputs(b, fp);
}

